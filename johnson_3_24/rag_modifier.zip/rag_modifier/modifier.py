
import google.generativeai as genai

def modify_config_segment(api_key: str, original_segment: str, user_request: str):
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel("gemini-pro")

    prompt = f"""你是一個網路設定檔維護助手，請根據使用者要求，修改以下設定段落：

原始段落：
{original_segment}

使用者要求：
{user_request}

請只輸出修改後的段落。"""

    response = model.generate_content(prompt)
    return response.text.strip()
